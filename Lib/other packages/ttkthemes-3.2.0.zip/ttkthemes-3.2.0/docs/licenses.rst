Licenses
========

The themes included in the ``ttkthemes`` package have been released
under various different licenses, including the BSD-2-clause-like Tcl
License, GNU GPLv2+ and GNU GPLv3. Note that the only license under
which all themes are available together is GNU GPLv3. Most of the code
is available under GNU GPLv3 only. If code is available under any  other
license, it is indicated in the specific files and folders.
