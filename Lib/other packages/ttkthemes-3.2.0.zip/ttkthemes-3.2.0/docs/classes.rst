Reference
=========

.. autoclass:: ttkthemes.themed_style.ThemedStyle
   :show-inheritance:
   :special-members:
   :members:

.. autoclass:: ttkthemes.themed_tk.ThemedTk
   :show-inheritance:
   :special-members:
   :members:

.. autoclass:: ttkthemes._widget.ThemedWidget
   :show-inheritance:
   :members:
